let persons = [
    {firstName: "Jim", lastName: "Jimithy", age: 15},
    {firstName: "Peter", lastName: "Peterson", age: 25},
    {firstName: "Carl", lastName: "Carlson", age: 28},
    {firstName: "Jane", lastName: "Janison", age: 22}
];

//TODO

console.log(oldestPerson); // { firstName: 'Carl', lastName: 'Carlson', age: 28 }