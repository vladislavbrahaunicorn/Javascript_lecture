
function isPalindrom(word) {
    //TODO
}

console.log(isPalindrom("ohoho")); //true
