var changes = "+++-+---++--+-+-++";

function countOfChages(str) {
    //TODO
}

console.log(countOfChages(changes)); //10