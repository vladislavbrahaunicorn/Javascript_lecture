
function camelToSnake(camel) {
    //TODO
}

console.log(camelToSnake("someNewWordToTransformAndA")); //some_new_word_to_transform_and_a
