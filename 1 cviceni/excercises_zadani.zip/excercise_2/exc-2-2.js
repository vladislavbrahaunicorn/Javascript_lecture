
function snakeToCamel(snake) {
    //TODO
}

console.log(snakeToCamel("some_new_word_to_transform_and_a")); //someNewWordToTransformAndA