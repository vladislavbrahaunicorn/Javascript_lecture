//single line comment and something else
var txt = "Hello World!";


console.log(txt)
