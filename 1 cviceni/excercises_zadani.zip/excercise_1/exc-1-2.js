var input2 = [1, 2, 4, 6, 9, 11, 11, 12];
var input3 = [1, 2, 4, 6, 9, 11, 11, 12, 13];

function findMedian(arr) {
    //TODO
}

console.log(findMedian(input2)); // 7.5
console.log(findMedian(input3)); // 9

