var input6 = {a: 1, b: 2, ccc: "abl", "d": true};

function objectToString(obj) {
    //TODO
}

console.log(objectToString(input6)); //(a -> 1; b -> 2; ccc -> abl; d -> true)