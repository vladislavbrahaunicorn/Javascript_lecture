var input = [1, 3, 6, 0, 5, -2, 9, 11, 16];

//TODO


console.log(total) ; // 20