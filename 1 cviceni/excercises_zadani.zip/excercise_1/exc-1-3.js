var input4 = [1, 2, 2, 4, 6, 9, 11, 12, 11, 666];

function findModus(arr) {
    //TODO
}

console.log(findModus(input4)); //[ 2, 11 ]