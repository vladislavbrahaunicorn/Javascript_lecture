var anotherObj = {
    a: 1,
    _b: 2,
    _c: 4,
    _d: () => {},
    e: () => {}
};

//TODO

console.log(anotherObj); //{ a: 1, e: [Function: e] }
