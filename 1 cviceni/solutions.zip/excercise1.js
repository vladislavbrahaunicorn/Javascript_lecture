




//1.1 sum of even elements of array
var input = [1, 3, 6, 0, 5, -2, 9, 11, 16];
var total = 0;
for (var i = 0; i < input.length; i += 1) {
    var element = input[i];
    if (element % 2 === 0) {
        total += element
    }
}

console.log(total) ;//20
console.log();

















//1.2 median
var input2 = [1, 2, 4, 6, 9, 11, 11, 12];
var input3 = [1, 2, 4, 6, 9, 11, 11, 12, 13];

function findMedian(arr) {
    var index = (arr.length / 2);
    var median;
    if (index % 1 === 0) {
        median = (arr[index - 1] + arr[index]) / 2
    } else {
        median = arr[index - 0.5] //or Math.floor
    }

    return median
}


console.log(findMedian(input2));
console.log(findMedian(input3));
console.log();

















//1.3 modus

var input4 = [1, 2, 2, 4, 6, 9, 11, 12, 11, 666];

function findModus(arr) {
    let counts = {};
    let largest = 0;
    for (var element of arr) {
        if (counts[element] === undefined) {
            counts[element] = 0
        }
        counts[element] += 1;
        if (counts[element] > largest) {
            largest = counts[element];
        }
    }

    let result = [];
    for (var key in counts) {
        if (counts[key] === largest) {
            result.push(Number(key))
        }
    }

    return result
}

console.log(findModus(input4));
console.log();
















//1.4
input5 = [1, 4, 2, 1, 2, 2, 2, 3, 9, 8, 33];

function findUnique(arr) {
    let values = {};

    for (var element of arr) {
        if (values[element] === undefined) {
            values[element] = true
        } else {
            values[element] = false
        }
    }

    let result = [];
    for (var key in values) {
        if (values[key] === true) {
            result.push(Number(key))
        }
    }

    return result
}

console.log(findUnique(input5));














//1.5
var input6 = {a: 1, b: 2, ccc: "abl", "d": true};

function objectToString(obj) {
    let result = "(";
    let index = 0;
    for (var key in obj) {
        result += key + " -> " + obj[key];
        if (index !== (Object.keys(obj).length - 1)) {
            result += "; "
        }
        index += 1
    }
    result += ")";
    return result
}

console.log(objectToString(input6)); //(a -> 1; b -> 2; ccc -> abl; d -> true)












