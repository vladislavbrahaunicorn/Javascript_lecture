//4.1

var obj = {
  a: 2,
  b: "22",
  c: false,
  d: "b",
  f: 3.14,
  g: 42
};

var count = Object.values(obj).filter((x) => typeof x === "number").length;
console.log(count);

//4.2

var newObj = {
  oldValues: [],
  _value: 0,
  set value(val) {
    this.oldValues.push(this.value);
    this._value = val
  },
  get value() {
    return this._value
  }
};

newObj.value = 1;
newObj.value = 2;
newObj.value = 3;
newObj.value = 4;
console.log(newObj.oldValues); // [0, 1, 2, 3]


//4.3

var anotherObj = {
  a: 1,
  _b: 2,
  _c: 4,
  _d: () => {},
  e: () => {}
};

Object.keys(anotherObj).filter(x => x[0] === "_").forEach(key => delete anotherObj[key]);
console.log(anotherObj); //{ a: 1, e: [Function: e] }











