









//3.1

var points = [5,6,3,2,1,8,4,6,-2,2,-1];
points.sort((a,b) => b - a);

console.log(points);













//3.2


function acceptThreeFunctions(a,b,c, number = 42) {
  var aResult = a(number);
  var bResult = b(number);
  var cResult = c(number);

  return Math.max(aResult, bResult, cResult)
}


console.log(acceptThreeFunctions(a => a * 2, b => b * 3, c => c * 4));













//3.3
let persons = [
  {firstName: "Jim", lastName: "Jimithy", age: 15},
  {firstName: "Peter", lastName: "Peterson", age: 25},
  {firstName: "Carl", lastName: "Carlson", age: 28},
  {firstName: "Jane", lastName: "Janison", age: 22}
];

var oldestPerson = persons.reduce((oldest, element) => {  
  if (oldest.age < element.age) {
    oldest = element
  }
  return oldest
});

console.log(oldestPerson);













//3.4
var persons2 = persons.map((person) => {
  person.luckyNumber = (person.firstName + " " + person.lastName).length;
  return person
});

console.log(persons2);
















//3.5
var points2 = [5,6,3,2,1,8,4,6,-2,2,-55];

function getNthSmallest(arr, n) {
  arr.sort((a,b) => a - b);
  return arr[n-1]
}

console.log(getNthSmallest(points2, 4));







