
//2.1

function camelToSnake(camel) {
  var characters = camel.split("");
  for (var i = 0; i < characters.length; i += 1) {
    if (isUpperCase(characters[i])) {
      characters[i] = "_" + characters[i].toLowerCase()
    } else {
      //characters[i] = characters[i].toLowerCase()
    }
  }
  return characters.join("")
}


function isUpperCase(char) {
  if (char) {
    return char === char.toUpperCase()
  } else {
    return false
  }
}

console.log(camelToSnake("someNewWordToTransformAndA"));














//2.2

 function snakeToCamel(snake) {
   var words = snake.split("_");
   for (var i = 0; i < words.length; i += 1) {
      if (i > 0) {
        var word = words[i];
        word = word[0].toUpperCase() + word.slice(1);
        words[i] = word
      }
   }
   return words.join("");
 }

console.log(snakeToCamel("some_new_word_to_transform_and_a"));
console.log();
















//2.3
function isPalindrom(word) {
  return word === word.split("").reverse().join("")
}

console.log(isPalindrom("ohoho"));
console.log();
















//2.4

//id, name, age
var csvInput = "1,  Peter,  22;" +
               "2, Jim, 11,;" +
               "3, P eeter, 8 ;";

function tranformCsv(string) {
  var results = [];
  var rows = string.split(";");
  rows.pop();

  for (var row of rows) {
    var elements = row.split(",");
    results.push({
      id: Number(elements[0]),
      name: elements[1].trim(),
      age: Number(elements[2])
    })
  }

  return results
}

console.log(tranformCsv(csvInput));
console.log();














//2.5

var changes = "+++-+---++--+-+-++";

function countOfChages(str) {
  var chars = str.split("");
  let count = 0;

  for (var i = 0; i < chars.length; i += 1) {
    if (i > 0 && chars[i] !== chars[i-1]) {
      //console.log(i + ":" + chars[i-1] + ":" + chars[i]);
      count += 1;
    }
  }

  return count
}

console.log(countOfChages(changes));




