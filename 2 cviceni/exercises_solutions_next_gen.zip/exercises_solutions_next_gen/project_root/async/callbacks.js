"use strict";

// CALLBACKS
// let's start with an example of a wrong implementation

const fs = require('fs');


fs.readFile('/some/file/that/does-not-exist', (err, data) => {
  // mistaken assumption: throwing here...
  if (err) {
    console.error(err);
  }
});

