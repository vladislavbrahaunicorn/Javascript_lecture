// Error handling

// callback
getUser(userName, (error, user) => {
  if (error) {
    // handle error here
  }
  console.log(user.name);
});


// promise API
getUser(userName)
  .then(user => {
    console.log(user.name); 
  })
  .catch(error => {
    // handle error here
  });
  
  
// async await  
 async function fetchUser() {
  try {
    const user = await getUser(userName); // <- async operation
    return user;
  } catch (error) {
    // handle error here
  }
}