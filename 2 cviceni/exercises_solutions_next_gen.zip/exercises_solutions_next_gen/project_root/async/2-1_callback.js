
function addString(previous, current, callback) {
  setTimeout(
      () => {
        callback((previous + ' ' + current))
      },
      Math.floor(Math.random() * 100) + 1
  )
}

function addAll(value) {
  addString(value, 'A', (value) => {
    addString(value, 'B', (value) => {
      addString(value, 'C', (value) => {
        console.log(value);
      });
    });
  });
}
addAll("");






function addA(value) {
  addString(value, 'A', addB);
}

function addB(value) {
  addString(value, 'B', addC);
}

function addC(value) {
  addString(value, 'C', print);
}

function print(value) {
  console.log(value);
}

function addAllThisWay() {
  addA('');
}

addAllThisWay();
