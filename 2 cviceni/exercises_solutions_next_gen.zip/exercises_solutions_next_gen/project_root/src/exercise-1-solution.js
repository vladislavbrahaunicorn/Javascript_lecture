/*
can't use Boolean(value)
consume any number of parameters
return array of objects
object per single param passed to the function
each object should contains:
   - isFalsy
   - type
   - stringLength
   - index
  [
        {
            "isFalsy": false,
            "type": "number",
            "StringLength": 1,
            "index": 0
        },
        ...
  ]
 */

function getInfo() {
  var values = Array.from(arguments);
  var results = [];

  var index = 0;
  values.forEach((value) => {
    var isFalsy = (!value);
    var type = typeof value;
    var StringLength = String(value).length;

    results.push({
      isFalsy,
      type,
      StringLength,
      index
    });
    index += 1
  });
  return results
}

module.exports = getInfo;