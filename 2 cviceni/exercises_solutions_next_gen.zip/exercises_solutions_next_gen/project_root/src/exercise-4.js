/*
use new binding to create object from Factory
created instance should have following functions:
  produceCar(color="red", wheels=4,engine=false)
  - at first, you need to check that you have enough power for creating a new car (2 power per car)
  - if there is not enough energy, shift energy from energyBoosts using addEnergy function
  - this function produce object representing a car with structure below:
    {
    id: 0 //auto incremented value which should be stored in warehouse
    color: "...", //from param
    wheels: "...", //from param
    engine: "...", //from param
    }
  - store created car in the warehouse and increment nextIdentifier
  addEnergyPower(value=0)
    add energy to factory
  changeColor(car, newColor)
  - at first, you need to check that you have enough power to change a color(1 power per car)
  - if there is not enough energy, shift energy from energyBoosts using addEnergy function
  - change the color

*/

const Factory = require("./lib/factory");
const myFactory = new Factory(10);
let energyBoosts = [7,3,4,5,4]; //energyBoosts.shift()

let numberOfCars = 0;
while (numberOfCars < 14) {
  myFactory.produceCar();
  numberOfCars += 1
  //...
}

//additionally change color for every odd car
for (let i = 0; i < myFactory.warehouse.createdCars.length; i += 2) {
  let car = myFactory.warehouse.createdCars[i]

  //...
}

//myFactory.warehouse; //JSON.stringify(myFactory.warehouse, null, 2)

