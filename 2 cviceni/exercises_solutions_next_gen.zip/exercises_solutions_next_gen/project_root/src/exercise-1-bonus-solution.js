/*
fill the function that executes each value with a function that has the same name as the typeof value
these functions are passed as the first parameter in the object like this:
{
string: function(value) { ... },
default: function(value) { ... }
}
the second parameter is an array of values to be processed
if there is no corresponding function, use the default one
these function could throw an error, so you have to handle them
  - each error has status and code
  - if the error status (e.status) is over 500, rethrow the error, if not, console log the e.code
store the result of each function call
filter results out of null and undefined
return following structure in the array for each input value:
{
input: "...",
result: "..."
}
*/

function process(functions = {}, values = []) {
  let functionResults = [];

  values.forEach((value) => {
    let func = functions[typeof value];
    if (!func) {
      func = functions["default"]
    }
    let functionResult;
    try {
      functionResult = func(value);
    } catch (e) {
      if (e.status && e.status < 500) {
        console.log(e.code);
        functionResult = undefined;
      } else {
        throw e;
      }
    }
    functionResults.push(functionResult);
  });

  let results = [];
  functionResults.forEach((outputValue, index) => {
    if (outputValue != null) {
      results.push({
        input: values[index],
        output: outputValue
      })
    }
  });

  return results
}


module.exports = process;

