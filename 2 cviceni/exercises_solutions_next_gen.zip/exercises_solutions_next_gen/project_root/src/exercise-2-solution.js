/*
validationTypes should export functions with names: String, Number, Any
each function consume one parameter and check if the passed value is the corresponding type

validate is the function that consume two parameters:
- object with schema
- object with values
both objects share the same keys
iterate over these keys to run function from the schema with a value from the second object
store invalid values
 */


const ValidationTypes = require("./lib/validation-types");
const {validate} = require("./lib/validation");

//Object.keys(schema)
const schema = {
  name: ValidationTypes.String,
  age: ValidationTypes.Number,
  extra: ValidationTypes.Any,
};

const values = {
  name: "John",
  age: "",
  extra: false,
};

let result = validate(schema, values); //return array of invalid keys
console.log(result.length === 0 ? "valid" : "invalid keys: " + result.join(", "));
//invalid keys: age

